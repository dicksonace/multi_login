<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Teachers Page</title>
</head>
<body>

	<?php include("includes/header.php"); ?>

</body>
</html>